<?php /** @noinspection ALL */
namespace App\Service;

use App\Entity\Person;
use Doctrine\ORM\EntityManagerInterface;

class PersonService
{
    private EntityManagerInterface $entityManager;

    public function __construct(EntityManagerInterface $entityManager) {

        $this->entityManager = $entityManager;
    }
    public function createPerson(string $firstName, string $lastName, string $email): Person {

        $person = new Person();
        $person->setFirstName($firstName);
        $person->setLastName($lastName);
        $person->setEmail($email);

        $this->entityManager->persist($person);

        $this->entityManager->flush();

        return $person;
    }
    public function loadPerson(int $id) {

        return $this->entityManager->find(Person::class, $id);
    }
    public function savePerson(Person $person) {

        $this->entityManager->flush();
    }

    public function deletePerson(int $id) {

        $person = $this->loadPerson($id);

        if ($person) {
            $this->entityManager->remove($person);
            $this->entityManager->flush();
            return true;
        }

        return false;
    }

    public function loadAllPeople() {

        $personRepository = $this->entityManager->getRepository(Person::class);
        return $personRepository->findAll();
    }

    public function deleteAllPeople() {

        $query = $this->entityManager->createQuery('DELETE FROM App\Entity\Person p');
        $numDeleted = $query->execute();
        return $numDeleted;
    }
}