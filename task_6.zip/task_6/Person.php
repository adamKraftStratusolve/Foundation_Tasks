<?php
namespace App\Entity;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'people')]
class Person
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\Column(type: 'string')]
    private string $firstName;

    #[ORM\Column(type: 'string')]
    private string $lastName;

    #[ORM\Column(type: 'string', unique: true)]
    private string $email;

    public function getId() {

        return $this->id;
    }

    public function getFirstName() {

        return $this->firstName;
    }

    public function setFirstName(string $firstName) {

        $this->firstName = $firstName;
    }

    public function getLastName() {

        return $this->lastName;
    }

    public function setLastName(string $lastName) {

        $this->lastName = $lastName;
    }

    public function getEmail() {

        return $this->email;
    }

    public function setEmail(string $email) {

        $this->email = $email;
    }
}